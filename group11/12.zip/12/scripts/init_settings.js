var _page_settings = {
	
	};

settings.init(_page_settings);