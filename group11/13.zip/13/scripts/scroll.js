function scroll(sSelector) {
    //-------------
    var s = this;
    //Методы
    s.showHideTopBtn = function() {
       
    };
    s.slowScroll = function() {

    };

    s.main = function() {
            s.init(sSelector);
            //Свойства
            s.topBtn = $('.topBtn');

            //События
            $(window).scroll(s.showHideTopBtn);
            s.topBtn.click(s.slowScroll);

        }
        //-------------
    $(document).ready(s.main);

}



scroll.prototype = new Component();